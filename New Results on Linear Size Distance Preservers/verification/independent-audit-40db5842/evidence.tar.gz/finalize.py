from pathlib import Path
import json,re,hashlib,datetime
b=Path('/workspace/shared/distance-preserver-continuation'); o=b/'independent-audit-40db5842-20261010'; p=b/'audit-updated-40db5842'
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
checks=json.load(open(o/'hash-verification.json')); roots=json.load(open(o/'root-body-closures.json')); ci=json.load(open(o/'ci-index-verification.json'))
fresh=[]; replay=[]
for kind,arr in [('fresh',fresh),('kernel',replay)]:
 for f in sorted((o/'raw').glob(kind+'-batch-*.log')):
  for name,code,time in re.findall(r'^RESULT (\S+) (\d+) (\S+)',f.read_text(),re.M):
   arr.append({'module':'LinearDistancePreservers.'+name,'exit_code':int(code),'finished_at':time,'log':str((o/'raw'/(kind+'-'+name+'.log')).relative_to(o))})
partial=json.load(open(o/'generated-partial-inventory.json'))
report={
 'schema_version':1,'audit_date_utc':'2026-10-10','frozen_commit':checks.get('commit','40db5842cc89370c32e0b6ba64e231969f771ef0'),'frozen_tree':checks['git_tree'],
 'manifest_sha256':checks['manifest_sha256'],'verdict':'QUALIFIED_PASS_CORRECTED_PARTIAL_MATHEMATICS','original_paper_complete':False,
 'mathematical_blockers_found':[],
 'finding_ids':['F1'],
 'findings':[{'id':'F1','severity':'minor_documentation','file':'New Results on Linear Size Distance Preservers/README.md','lines':[[132,139],[193,195]],'finding':'Two unmarked current-scope paragraphs still describe the now-proved displayed growing-dimension range as unproved.','impact':'Contradictory underclaim of current coverage; no invalid mathematical proof or original-paper completion claim.','remedy':'Owner supplied a narrow out-of-target README patch, independently checked to apply cleanly and match the live README. Frozen target unchanged.','remedy_verification':'readme-remedy-verification.json'}],
 'qualifications':[
  'The original unweighted square-root-logarithmic-deficit existential superquadratic assertion remains unresolved.',
  'The printed Euclidean weighting is disproved; the quadratic repair establishes the corrected existential construction, not the literal assignment.',
  'The source RS prose convention is corrected to the standard induced-matching extremal quantity.',
  'Theorem 1 covers finite nonnegative real weights; generic weighted Lemma 7 covers finite strictly positive actual input-edge weights, with inner symmetry separately conditional.',
  'Nonzero subset lower bounds require at least two terminals; exported distinct indexed auxiliary paths require positive depth.',
  'The quarter-root finite domain may be empty at small sizes, as the frozen detailed documentation already says; its range is eventually nonempty.',
  'ConstructionEnvelope, the displayed-expression obstruction and SubdivisionBarrier have only their stated restricted scopes.',
  'Quoted background estimates, signed/infinite-weight generalizations and open questions are not claimed verified.'
 ],
 'integrity':checks,'ci':ci,'live_ci_job_verification':'raw/github-live-job-verification.json',
 'verification':{'fresh_source_elaborations':fresh,'official_module_kernel_replays':replay,'project_declarations':1937,'checked_type_body_union_constants':49091,'allowed_axioms':['propext','Classical.choice','Quot.sound'],'unsafe_union_constants':[],'partial_generated_union_constants':partial,'all_twelve_main_result_closures_have_no_unsafe_or_partial':all(not r['unsafe'] and not r['partial'] for r in roots),'root_closures':roots,'dependency_modules_hashed':1744,'dependency_module_manifest':'dependency-module-hashes.json','initial_paper_artifact_manifest':'initial-artifacts.json'},
 'checks_not_run':['No full local rebuild of all 112 paper modules or all mathlib sources. Exact-commit full CI was independently checked instead, supplemented by fresh selected local elaboration.','No fresh local official replay of every 112 paper module; exact-commit CI enumerates all 112.','Other three papers in the repository are outside this semantic audit, although their gates appear in the same CI log.','No public Site or GitHub publication by this auditor.'],
 'method_boundaries':['Source-level comparison and risk-based proof-spine inspection, not a claim to have manually read every line of every imported proof.','All 1937 frozen paper declarations were inventoried by defining module, including private/generated names.','The body-closure walk reads checked ConstantInfo types and opaque/theorem/definition bodies rather than relying only on collectAxioms cached metadata.','Standard Lean kernel and the three listed axioms remain trusted; this is not an external foundational verifier.','The frozen 112-module import root was used; two subsequent working-checkout obstruction modules were not imported.'],
 'artifacts':{'report':'REPORT.md','semantic_findings':'semantic-findings.md','statement_extracts':'statements/inspected-statements.json','elaborated_types':'raw/closure-audit-4.log','full_dependency_graph':'raw/body-closure.json','axiom_and_body_audit_source':'AuditFrozen.lean','fresh_replay_driver':'ReplayClosure.lean','supplementary_nonvacuity_source':'Nonvacuity.lean'}
}
# Supplementary checks are added only when successful logs really exist.
extra=[]
for f in sorted((o/'raw').glob('fresh-closure-*.log')):
 s=f.read_text();m=re.search(r'FRESH_REPLAY_PASS root=(\S+) constants=(\d+)',s)
 extra.append({'log':str(f.relative_to(o)),'passed':bool(m),'root':m.group(1) if m else None,'constants':int(m.group(2)) if m else None})
report['verification']['empty_kernel_environment_replays']=extra
nf=o/'raw/nonvacuity-status.json'
if nf.exists():report['verification']['supplementary_nonvacuity']=json.load(open(nf))
# Reverify frozen hash manifest after all work.
man=json.load(open(p/'manifest.json'));changed=[n for n,x in man['sha256'].items() if h(p/n)!=x]
report['integrity']['final_frozen_mismatches']=changed
if changed: raise RuntimeError(changed)
(o/'verdict.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
