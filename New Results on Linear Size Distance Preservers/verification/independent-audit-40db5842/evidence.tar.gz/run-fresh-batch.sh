#!/usr/bin/env bash
set -uo pipefail
O=/workspace/shared/distance-preserver-continuation/independent-audit-40db5842-20261010
P='/workspace/shared/distance-preserver-continuation/audit-updated-40db5842/repo/New Results on Linear Size Distance Preservers'
source "$O/env.sh"
exec 9>/workspace/shared/formalization-compiler.lock
flock -n 9 || exit 75
start=$SECONDS
echo "ACQUIRED $(date -u +%FT%TZ) $*"
for m in "$@"; do
  if (( SECONDS-start > 35 )); then echo BATCH_DEFERRED "$m"; break; fi
  for f in "$O/compiled/LinearDistancePreservers/$m".olean* "$O/compiled/LinearDistancePreservers/$m".ilean; do
    if [[ -L "$f" ]]; then rm "$f"; fi
  done
  echo "COMMAND lean -j1 -DautoImplicit=false -o $O/compiled/LinearDistancePreservers/$m.olean LinearDistancePreservers/$m.lean"
  (cd "$P" && timeout "$((55-(SECONDS-start)))s" lean -j1 -DautoImplicit=false -o "$O/compiled/LinearDistancePreservers/$m.olean" "LinearDistancePreservers/$m.lean") > "$O/raw/fresh-$m.log" 2>&1
  status=$?
  echo "RESULT $m $status $(date -u +%FT%TZ)"
  if (( status != 0 )); then cat "$O/raw/fresh-$m.log"; break; fi
  if (( SECONDS-start > 50 )); then break; fi
done
echo "RELEASED $(date -u +%FT%TZ)"
exit "${status:-0}"
