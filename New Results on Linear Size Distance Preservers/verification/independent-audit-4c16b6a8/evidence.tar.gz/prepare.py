from pathlib import Path
import json,hashlib,subprocess
b=Path('/workspace/shared/distance-preserver-continuation'); p=b/'audit-accepted-4c16b6a8'; o=b/'independent-audit-4c16b6a8-20261012'; w=b/'repo'; r=p/'repo'; paper=Path('New Results on Linear Size Distance Preservers'); sh=lambda x:hashlib.sha256(x).hexdigest()
for sub in ['raw','compiled/LinearDistancePreservers','statements']:(o/sub).mkdir(parents=True,exist_ok=True)
m=json.loads((p/'manifest.json').read_text()); bad=[x for x,h in m['file_sha256'].items() if sh((p/x).read_bytes())!=h]
assert not bad,bad
assert sh((p/'manifest.json').read_bytes())=='06b92c57abeb798b74d108ff25a633a5660e0ccfdeac39940528a5d02b6ff05b'
assert sh((b/'HANDOFF-20261012-0044.md').read_bytes())=='e3da4b14120f2ee56bca6bf7089513ada60ecc78327b7171eb5d24a3131db73a'
sha=m['candidate_commit']; tree=subprocess.check_output(['git','rev-parse',sha+'^{tree}'],cwd=w,text=True).strip(); assert tree==m['candidate_tree']
blobs=subprocess.check_output(['git','ls-tree','-rz',sha],cwd=w).split(b'\0'); files=[]
for row in blobs:
 if not row:continue
 head,f=row.split(b'\t'); mode,typ,blob=head.split(); f=f.decode(); data=(r/f).read_bytes(); actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(); assert actual==blob.decode(),f
 assert (w/f).read_bytes()==data,f
 files.append({'path':f,'git_blob':actual,'sha256':sh(data)})
extra=sorted(set(str(f.relative_to(r)) for f in r.rglob('*') if f.is_file())-set(x['path'] for x in files)); assert not extra,extra
modules=sorted((r/paper/'LinearDistancePreservers').glob('*.lean')); assert len(modules)==116
prior=[]
for f in modules:
 rel=str(f.relative_to(r)); a=subprocess.check_output(['git','show',m['mathematical_commit']+':'+rel],cwd=w); assert a==f.read_bytes()
 proc=subprocess.run(['git','show','40db5842:'+rel],cwd=w,capture_output=True)
 if proc.returncode==0:assert proc.stdout==f.read_bytes(),rel;prior.append(rel)
assert len(prior)==112
(o/'source-verification.json').write_text(json.dumps({'manifest_sha256':sh((p/'manifest.json').read_bytes()),'manifest_files':len(m['file_sha256']),'commit':sha,'tree':tree,'archive_files':files,'same_parent_math_modules':116,'same_prior_math_modules':112,'all_working_source_bytes_match':True},indent=2))
# The first LEAN_PATH root shadows the whole library directory; fill unchanged imports with read-only symlinks.
for a in (w/'.lake/build/lib/lean/LinearDistancePreservers').iterdir():
 t=o/'compiled/LinearDistancePreservers'/a.name
 if not t.exists() and not t.is_symlink():t.symlink_to(a)
a=w/'.lake/build/lib/lean/LinearDistancePreservers.olean';t=o/'compiled/LinearDistancePreservers.olean'
if not t.exists() and not t.is_symlink():t.symlink_to(a)
paths=[o/'compiled',w/'.lake/build/lib/lean']+sorted((w/'.lake/packages').glob('*/.lake/build/lib/lean'))
(o/'env.sh').write_text('export PATH="/workspace/shared/flow-cut-emergency-recovery-20261010T1151Z/toolchain/lean-4.34.0-linux/bin:$PATH"\nexport LEAN_PATH="'+':'.join(map(str,paths))+'"\n')
art=[]
for f in modules:
 base=w/'.lake/build/lib/lean/LinearDistancePreservers'/f.stem
 for a in base.parent.glob(f.stem+'.*'):
  art.append({'module':'LinearDistancePreservers.'+f.stem,'source_sha256':sh(f.read_bytes()),'artifact':str(a),'sha256':sh(a.read_bytes())})
(o/'initial-artifacts.json').write_text(json.dumps(art,indent=2))
roots=json.loads((r/paper/'verification/accepted-statement-map.json').read_text())['exports']
source=(b/'independent-audit-40db5842-20261010/AuditFrozen.lean').read_text(); source=source[source.index('import Lean.Util.CollectAxioms'):source.index('\n#check')]
source=source.replace('1937','2074').replace(str(b/'independent-audit-40db5842-20261010'),str(o))
source=source.replace('("name",toJson name.toString),("module",toJson (modName name).toString),','("name",toJson name.toString),("module",toJson (modName name).toString),\n      ("kind",toJson (match ci with | .thmInfo _ => "theorem" | .defnInfo _ => "definition" | .opaqueInfo _ => "opaque" | .axiomInfo _ => "axiom" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor" | .quotInfo _ => "quotient")),\n      ("type_hash",toJson (hash ci.type).toNat), ("body_hash", toJson ((ci.value? true).map fun e => (hash e).toNat)),')
(o/'AuditFrozen.lean').write_text((r/paper/'LinearDistancePreservers.lean').read_text()+source+'\n'.join('\n#check '+x['declaration']+'\n#print axioms '+x['declaration'] for x in roots))
(o/'roots.json').write_text(json.dumps(roots,indent=2))
(o/'ReplayClosure.lean').write_text((b/'independent-audit-40db5842-20261010/ReplayClosure.lean').read_text())
for name in ['fresh','replay']:
 s=(b/f'independent-audit-40db5842-20261010/run-{name}-batch.sh').read_text().replace('independent-audit-40db5842-20261010',o.name).replace('audit-updated-40db5842','audit-accepted-4c16b6a8')
 (o/f'run-{name}-batch.sh').write_text(s)
print('PASS',len(m['file_sha256']),'manifest files;',len(files),'Git archive files; 116 parent sources and112 prior audit sources unchanged')
