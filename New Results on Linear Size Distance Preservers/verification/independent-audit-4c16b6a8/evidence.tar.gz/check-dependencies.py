from pathlib import Path
import hashlib,json,subprocess,collections
b=Path('/workspace/shared/distance-preserver-continuation');o=b/'independent-audit-4c16b6a8-20261012';w=b/'repo'; tool=Path('/workspace/shared/flow-cut-emergency-recovery-20261010T1151Z/toolchain/lean-4.34.0-linux');sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
rows=json.loads((o/'raw/body-closure.json').read_text());mods=sorted({r['module'] for r in rows if r['module']!='[anonymous]'}); packages=list((w/'.lake/packages').iterdir()); srcroots=[w/'New Results on Linear Size Distance Preservers']+packages+[tool/'src/lean'];artroots=[o/'compiled',w/'.lake/build/lib/lean']+[p/'.lake/build/lib/lean' for p in packages]+[tool/'lib/lean'];out=[]
manifest=json.loads((w/'lake-manifest.json').read_text()); pins={p['name']:p['rev'] for p in manifest['packages']};gitmaps={}; pinrows=[]
for p in packages:
 if p.name not in pins:continue
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=p,text=True).strip();assert head==pins[p.name],(p.name,head)
 data=subprocess.check_output(['git','ls-tree','-rz','HEAD'],cwd=p); gm={}
 for row in data.split(b'\0'):
  if not row:continue
  h,f=row.split(b'\t');gm[f.decode()]=h.split()[2].decode()
 gitmaps[p]=gm;pinrows.append({'package':p.name,'head':head})
for m in mods:
 rel=Path(m.replace('.','/'));sources=[q/rel.with_suffix('.lean') for q in srcroots if (q/rel.with_suffix('.lean')).exists()];arts=[q/rel.with_suffix('.olean') for q in artroots if (q/rel.with_suffix('.olean')).exists()];assert sources,(m,'source missing');assert arts,(m,'artifact missing');s=sources[0];a=arts[0];record={'module':m,'source':str(s),'source_sha256':sha(s),'artifact':str(a),'artifact_sha256':sha(a)}
 for root,gm in gitmaps.items():
  if s.is_relative_to(root):
   data=s.read_bytes();bl=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(); assert gm[str(s.relative_to(root))]==bl,(m,'git mismatch');record['matches_dependency_git_blob']=True
 out.append(record)
(o/'dependency-module-hashes.json').write_text(json.dumps(out,indent=2));(o/'dependency-pins.json').write_text(json.dumps(pinrows,indent=2));print('PASS source/artifact hashes',len(out),'dependency pins',len(pinrows))
