from pathlib import Path
import json,subprocess,re,hashlib
import html
b=Path('/workspace/shared/distance-preserver-continuation');o=b/'independent-audit-4c16b6a8-20261012';p=b/'audit-accepted-4c16b6a8'; c=p/'companion'; site=b/'site'; ref='a58a0b96ea154731dfa77ad29eed60f945b1ff1d'; rel='dist/new-results-on-linear-size-distance-preservers/index.html';old=subprocess.check_output(['git','show',ref+':'+rel],cwd=site).decode();new=(c/rel).read_text(); strip=lambda s:re.sub(r'<!--LEAN_CHANGE_START-->.*?<!--LEAN_CHANGE_END-->','',s,flags=re.S)
assert strip(old)==strip(new),'Article/body change outside markers'
oldj=json.loads(subprocess.check_output(['git','show',ref+':lean-changes.json'],cwd=site));newj=json.loads((c/'lean-changes.json').read_text());assert oldj['placements']==newj['placements'][:10];assert len(newj['placements'])==12
for key in ['dp-2','dp-3','dp-4','dp-5']:
 assert next(x for x in oldj['changes'] if x['key']==key)==next(x for x in newj['changes'] if x['key']==key)
notes=re.findall(r'<!--LEAN_CHANGE_START-->(.*?)<!--LEAN_CHANGE_END-->',new,flags=re.S);assert len(notes)==12
for el in notes:
 key=re.search(r'data-change-key="([^"]+)"',el)[1];text=html.unescape(re.sub('<[^>]*>','',el))
 if key=='dp-1':assert 'k*x²+1+a²' in text and 'baseline' in text
 if key=='dp-6':assert '2n+p³' in text and 'not separately' in text
 if key=='dp-7':assert 'nonroot leaf' in text and 'no O(n²)' in text
for target in ['Thmtheorem5','Thmtheorem3','Thmtheorem4','Thmtheorem6','Thmlemma3','Thmlemma5']:
 assert f'id="{target}"' in new

assets=[]
for f in sorted((c/'dist/assets').rglob('*')):
 if f.is_file():
  relative=str(f.relative_to(c));data=subprocess.check_output(['git','show',ref+':'+relative],cwd=site);assert data==f.read_bytes();assets.append(relative)
plan=json.loads((p/'repo/New Results on Linear Size Distance Preservers/verification/accepted-marker-plan.json').read_text());assert newj==plan['candidate_annotations'];assert hashlib.sha256(new.encode()).hexdigest()==plan['candidate_html_sha256']
report={'base_site_commit':ref,'marker_counts':{'old':10,'new':12},'old_placements_exactly_preserved':True,'article_outside_marker_blocks_byte_identical':True,'assets_unchanged':len(assets),'actual_annotation_content_checked':True,'authoritative_plan_matches':True,'fresh_rendered_pixel_qa':False,'live_deployment_performed':False,'status_panel_requires_final_refresh':True}
(o/'companion-verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
# Run frozen candidate inputs but save test outputs only in auditor directory.
s=(p/'evidence/accepted-marker-check.cjs').read_text().replace(str(b/'accepted-completion-companion'),str(c));(o/'check-markers.cjs').write_text(s)
s=(c/'sources/test-dom.cjs').read_text().replace("path.resolve(__dirname,'../dist')",json.dumps(str(c/'dist'))).replace("path.join(__dirname,'dom-report.json')",json.dumps(str(o/'raw/companion-dom-report.json')));(o/'check-dom.cjs').write_text(s)
s=(c/'sources/test-diagrams.cjs').read_text().replace("'../dist/assets/diagrams.js'",json.dumps(str(c/'dist/assets/diagrams.js')));(o/'check-diagrams.cjs').write_text(s)
