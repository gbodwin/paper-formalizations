import Lean.CoreM
import Lean.Replay
import Lean.Util.FoldConsts
open Lean

-- Audit-only driver using Lean's official replay implementation. Unlike the
-- normal leanchecker module mode, this starts with an empty kernel environment.
unsafe def main (args : List String) : IO UInt32 := do
  let [moduleStr, rootStr] := args | throw <| IO.userError "Expected module and root"
  initSearchPath (← findSysroot)
  let module := moduleStr.toName
  let root := rootStr.toName
  Lean.withImportModules #[{module}] {} fun env => do
    let env := env.setExporting false
    let mut todo := #[root]
    let mut seen : NameSet := {}
    let mut cs : Std.HashMap Name ConstantInfo := {}
    let mut pos := 0
    while pos < todo.size do
      let name := todo[pos]!
      pos := pos+1
      if seen.contains name then continue
      seen := seen.insert name
      let some ci := env.checked.get.find? name | throw <| IO.userError s!"Missing checked body {name}"
      if ci.isUnsafe || ci.isPartial then throw <| IO.userError s!"Unsafe or partial proof dependency {name}"
      if let .axiomInfo _ := ci then
        unless #[`propext,`Classical.choice,`Quot.sound].contains name do
          throw <| IO.userError s!"Disallowed axiom {name}"
      cs := cs.insert name ci
      todo := todo ++ ci.getUsedConstantsAsSet.toArray
      if let .inductInfo v := ci then todo := todo ++ v.all.toArray
    IO.println s!"FRESH_REPLAY_BEGIN root={root} constants={cs.size}"
    let checked ← (← mkEmptyEnvironment).toKernelEnv.replay cs
    unless (checked.find? root).isSome do throw <| IO.userError "Root absent after replay"
    IO.println s!"FRESH_REPLAY_PASS root={root} constants={cs.size}"
  return 0
