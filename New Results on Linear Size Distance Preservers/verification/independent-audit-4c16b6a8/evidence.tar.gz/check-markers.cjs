const {JSDOM}=require('/workspace/shared/vft-continuation/testtools/node_modules/jsdom');
const fs=require('fs'),path=require('path'),assert=require('assert');
const report={dp:{files:['dist/new-results-on-linear-size-distance-preservers/index.html']}};
const targets={dp:'/workspace/shared/distance-preserver-continuation/audit-accepted-4c16b6a8/companion'};
const code=fs.readFileSync('/workspace/shared/distance-preserver-continuation/audit-accepted-4c16b6a8/companion/dist/assets/lean-changes.js','utf8');
(async()=>{let pages=0,markers=0,checks=0;
for(const [key,r] of Object.entries(report))for(const file of r.files){
 const s=fs.readFileSync(path.join(targets[key],file),'utf8');
 for(const width of [320,768,1440]){
  const dom=new JSDOM(s,{runScripts:'outside-only',url:'https://paperlab.example/'+file.replace(/^dist\//,'')});const w=dom.window,d=w.document;
  Object.defineProperty(w,'innerWidth',{value:width,writable:true});Object.defineProperty(w,'innerHeight',{value:640,writable:true});
  const notes=[...d.querySelectorAll('.lean-change')];assert(notes.length>0);
  const ids=[...d.querySelectorAll('[id]')].map(e=>e.id);assert.equal(new Set(ids).size,ids.length,'duplicate ids '+key);
  for(const el of notes){const b=el.querySelector('button'),p=el.querySelector('[role=note]');assert.equal(b.type,'button');assert.equal(b.getAttribute('aria-controls'),p.id);assert.equal(b.getAttribute('aria-describedby'),p.id);assert(b.getAttribute('aria-label').startsWith('Lean change:'));assert(p.textContent.includes('Original'));assert(p.hidden);b.getBoundingClientRect=()=>({left:width-40,top:600,bottom:632});Object.defineProperty(p,'offsetWidth',{get:()=>Math.min(400,width-24)});Object.defineProperty(p,'offsetHeight',{get:()=>260});}
  w.eval(code);
  for(const el of notes){const b=el.querySelector('button'),p=el.querySelector('[role=note]');
   b.focus();assert(!p.hidden,'focus opens');assert.equal(b.getAttribute('aria-expanded'),'true');b.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));assert(p.hidden);assert.equal(d.activeElement,b);
   b.click();assert(!p.hidden,'tap opens');b.click();assert(p.hidden,'second tap closes');
   b.click();p.querySelector('button').click();assert(p.hidden,'close control');assert.equal(d.activeElement,b);
   b.blur();el.dispatchEvent(new w.MouseEvent('mouseenter'));assert(!p.hidden,'hover opens');el.dispatchEvent(new w.MouseEvent('mouseleave'));await new Promise(r=>w.setTimeout(r,180));assert(p.hidden,'hover dismisses');
   b.click();d.body.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));assert(p.hidden,'outside click');
   b.click();const left=parseFloat(p.style.left),top=parseFloat(p.style.top);assert(left>=12&&left+p.offsetWidth<=width-12,'horizontal mobile fit');assert(top>=12&&top+p.offsetHeight<=640-12,'vertical fit');d.body.click();checks+=12;
  }
  if(notes.length>1){notes[0].querySelector('button').click();notes[1].querySelector('button').click();assert(notes[0].querySelector('[role=note]').hidden,'one popup');}
  if(key==='vft'){
 const oldMain=d.querySelector('main');const fresh=oldMain.cloneNode(true);fresh.querySelectorAll('.lean-change,.lean-change-legend').forEach(e=>e.remove());oldMain.replaceWith(fresh);await new Promise(r=>w.setTimeout(r,0));assert.equal(d.querySelectorAll('.lean-change').length,notes.length,'reader hydration restore');const b=d.querySelector('.lean-change-toggle');b.click();assert.equal(b.getAttribute('aria-expanded'),'true','restored click binds');b.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));assert.equal(b.getAttribute('aria-expanded'),'false');
 }
 if(width===320)markers+=notes.length;dom.window.close();
 }
 pages++;
}
console.log(JSON.stringify({pages,markers,viewportWidths:[320,768,1440],assertionGroups:checks,result:'PASS',renderedBrowserQA:false}));
})().catch(e=>{console.error(e);process.exit(1)});
