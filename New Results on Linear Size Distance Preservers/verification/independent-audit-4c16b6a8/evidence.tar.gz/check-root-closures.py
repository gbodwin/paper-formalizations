from pathlib import Path
import json,hashlib,collections
p=Path('/workspace/shared/distance-preserver-continuation/independent-audit-4c16b6a8-20261012');rows=json.loads((p/'raw/body-closure.json').read_text());ix={r['name']:r for r in rows};roots=[r['declaration'] for r in json.loads((p/'roots.json').read_text())];roots+=['LinearDistancePreservers.UnlayeredEnvelope.full_edge_sqrt_deficit','LinearDistancePreservers.UnlayeredEnvelope.full_product_sqrt_deficit','LinearDistancePreservers.NaturalBoundary.every_deficit_has_bounded_count_subsequence','LinearDistancePreservers.ConnectorPacking.star_metric_vertex_bound_edist','LinearDistancePreservers.ConnectorPacking.uniform_star_vertex_bound','LinearDistancePreservers.SharedCopyLift.cross_edist','LinearDistancePreservers.ModularGraph.canonical_support_injective','LinearDistancePreservers.ModularGraph.canonical_edge_owner_unique','LinearDistancePreservers.ObstacleProduct.product_weight_symmetric'];out=[]
for root in roots:
 seen=set();todo=[root]
 while todo:
  n=todo.pop()
  if n in seen:continue
  seen.add(n);todo+=ix[n]['deps']
 body=[ix[n] for n in sorted(seen)];data=json.dumps(body,sort_keys=True,separators=(',',':')).encode()
 out.append({'root':root,'constants':len(seen),'paper_constants':sum(ix[n]['module'].startswith('LinearDistancePreservers.') for n in seen),'axioms':sorted(n for n in seen if ix[n]['axiom']),'unsafe':sorted(n for n in seen if ix[n]['unsafe']),'partial':sorted(n for n in seen if ix[n]['partial']),'graph_sha256':hashlib.sha256(data).hexdigest(),'names':sorted(seen)})
 assert not out[-1]['unsafe'] and not out[-1]['partial'];assert set(out[-1]['axioms'])<=set(['propext','Classical.choice','Quot.sound'])
(p/'root-body-closures.json').write_text(json.dumps(out,indent=2));print('PASS roots:',len(out))
