import LinearDistancePreservers.BalancedCoefficient
import LinearDistancePreservers.BalancedRadius
import LinearDistancePreservers.BalancedVolume
import LinearDistancePreservers.Batching
import LinearDistancePreservers.BehrendPorts
import LinearDistancePreservers.BehrendProduct
import LinearDistancePreservers.Branching
import LinearDistancePreservers.CoefficientBounds
import LinearDistancePreservers.ConnectorPacking
import LinearDistancePreservers.ConsistentTiebreaking
import LinearDistancePreservers.ConstructionEnvelope
import LinearDistancePreservers.ConvexChains
import LinearDistancePreservers.ConvexDirections
import LinearDistancePreservers.ConvexRigidity
import LinearDistancePreservers.DirectionGraph
import LinearDistancePreservers.DirectionObstacle
import LinearDistancePreservers.DirectionPerfect
import LinearDistancePreservers.ExactLayerDirections
import LinearDistancePreservers.ExactLayerEncoding
import LinearDistancePreservers.ExplicitLatticeRadius
import LinearDistancePreservers.FavorableCut
import LinearDistancePreservers.FinitePerturbation
import LinearDistancePreservers.FixedGap
import LinearDistancePreservers.GrowingDimension
import LinearDistancePreservers.GrowingSuperquadratic
import LinearDistancePreservers.HigherBehrend
import LinearDistancePreservers.HigherParameters
import LinearDistancePreservers.HigherProduct
import LinearDistancePreservers.HigherRate
import LinearDistancePreservers.InducedMatchingRemoval
import LinearDistancePreservers.InducedMatchings
import LinearDistancePreservers.LatticeApproximation
import LinearDistancePreservers.LatticeBody
import LinearDistancePreservers.LatticeCapGrouping
import LinearDistancePreservers.LatticeCapVolume
import LinearDistancePreservers.LatticeCapWidth
import LinearDistancePreservers.LatticeCaps
import LinearDistancePreservers.LatticeCellVolume
import LinearDistancePreservers.LatticeDual
import LinearDistancePreservers.LatticeFlatness
import LinearDistancePreservers.LatticeHull
import LinearDistancePreservers.LatticeMinima
import LinearDistancePreservers.LatticeMissedVolume
import LinearDistancePreservers.LatticeProduct
import LinearDistancePreservers.LatticeScaling
import LinearDistancePreservers.LatticeShells
import LinearDistancePreservers.LatticeSliceVolume
import LinearDistancePreservers.LatticeSlicing
import LinearDistancePreservers.LatticeVertices
import LinearDistancePreservers.LayeredWalks
import LinearDistancePreservers.LazyTreeSelection
import LinearDistancePreservers.LowerBoundParameters
import LinearDistancePreservers.MatchingExtremal
import LinearDistancePreservers.ModularDistance
import LinearDistancePreservers.ModularGraph
import LinearDistancePreservers.ModularObstacle
import LinearDistancePreservers.ModularObstacleMetric
import LinearDistancePreservers.ModularPerfect
import LinearDistancePreservers.NativeWalkBridge
import LinearDistancePreservers.NaturalBoundary
import LinearDistancePreservers.NearThreshold
import LinearDistancePreservers.NearThresholdEventual
import LinearDistancePreservers.ObstacleCounting
import LinearDistancePreservers.ObstacleWalks
import LinearDistancePreservers.ObstacleWeights
import LinearDistancePreservers.OptimizedGap
import LinearDistancePreservers.PaperTheorem
import LinearDistancePreservers.PathLowerBound
import LinearDistancePreservers.PathPerturbation
import LinearDistancePreservers.PathUnion
import LinearDistancePreservers.PlanarBehrend
import LinearDistancePreservers.PlanarParameters
import LinearDistancePreservers.PlanarProduct
import LinearDistancePreservers.PolytopeApproximation
import LinearDistancePreservers.PreserverForcing
import LinearDistancePreservers.PreserverPadding
import LinearDistancePreservers.PrimitiveDirections
import LinearDistancePreservers.QuadraticRepair
import LinearDistancePreservers.QuantitativeRate
import LinearDistancePreservers.QuarterRootEventual
import LinearDistancePreservers.QuarterRootParameters
import LinearDistancePreservers.QuarterRootTheorem
import LinearDistancePreservers.RateFactorBounds
import LinearDistancePreservers.RootRate
import LinearDistancePreservers.RoutingOfPaths
import LinearDistancePreservers.SharedCopyLift
import LinearDistancePreservers.SphereCoefficients
import LinearDistancePreservers.SphereComparison
import LinearDistancePreservers.SphereDirections
import LinearDistancePreservers.SpherePower
import LinearDistancePreservers.SphereScales
import LinearDistancePreservers.SphereTheorem
import LinearDistancePreservers.SubdivisionBarrier
import LinearDistancePreservers.TheoremFourDense
import LinearDistancePreservers.TheoremFourGeneral
import LinearDistancePreservers.TheoremFourPlanar
import LinearDistancePreservers.TheoremFourRateAudit
import LinearDistancePreservers.TheoremOne
import LinearDistancePreservers.TheoremSix
import LinearDistancePreservers.TheoremThree
import LinearDistancePreservers.TheoremThreeExact
import LinearDistancePreservers.TheoremTwo
import LinearDistancePreservers.TreeCounting
import LinearDistancePreservers.UniformDimension
import LinearDistancePreservers.UnitVolumeBounds
import LinearDistancePreservers.UnlayeredEnvelope
import LinearDistancePreservers.UnweightedClique
import LinearDistancePreservers.UnweightedPadding
import LinearDistancePreservers.UnweightedPath
import LinearDistancePreservers.WalkSequence
import LinearDistancePreservers.WeightedConstruction
import LinearDistancePreservers.WeightedLexicographic
import LinearDistancePreservers.WeightedNativeForcing
import LinearDistancePreservers.WeightedPerturbation
import LinearDistancePreservers.WeightedProjection
import LinearDistancePreservers.WeightedSuperquadratic
import Lean.Util.CollectAxioms
import Lean.Util.FoldConsts
import Lean.Elab.Command
set_option maxHeartbeats 0
set_option pp.universes false
open Lean Elab Command in
run_cmd do
  let env := (← getEnv).setExporting false
  let mods := env.allImportedModuleNames
  let allowed : Array Name := #[`propext, `Classical.choice, `Quot.sound]
  let modName (n : Name) := match env.getModuleIdxFor? n with
    | some idx => mods[idx.toNat]?.getD .anonymous
    | none => .anonymous
  let mut project : Array Name := #[]
  for (name, _) in env.constants.toList do
    if (Name.mkSimple "LinearDistancePreservers").isPrefixOf (modName name) then
      project := project.push name
      let axs ← Lean.collectAxioms name
      for ax in axs do
        unless allowed.contains ax do throwError "DISALLOWED {name}: {ax}"
  unless project.size == 2074 do throwError "Unexpected declaration count: {project.size}"
  logInfo m!"PROJECT_AXIOM_AUDIT {project.size}"
  let mut todo := project
  let mut seen : NameSet := {}
  let mut pos := 0
  let mut rows : Array Json := #[]
  let mut axs : NameSet := {}
  let mut unsafeDecls : Array Name := #[]
  let mut partialDecls : Array Name := #[]
  while pos < todo.size do
    let name := todo[pos]!
    pos := pos+1
    if seen.contains name then continue
    seen := seen.insert name
    let some ci := env.checked.get.find? name | throwError "MISSING CHECKED BODY {name}"
    let deps := ci.getUsedConstantsAsSet.toArray
    todo := todo ++ deps
    let isAx := match ci with | .axiomInfo _ => true | _ => false
    if isAx then
      axs := axs.insert name
      unless allowed.contains name do throwError "BODY DISALLOWED {name}"
    if ci.isUnsafe then unsafeDecls := unsafeDecls.push name
    if ci.isPartial then partialDecls := partialDecls.push name
    rows := rows.push (Json.mkObj [
      ("name",toJson name.toString),("module",toJson (modName name).toString),
      ("kind",toJson (match ci with | .thmInfo _ => "theorem" | .defnInfo _ => "definition" | .opaqueInfo _ => "opaque" | .axiomInfo _ => "axiom" | .inductInfo _ => "inductive" | .ctorInfo _ => "constructor" | .recInfo _ => "recursor" | .quotInfo _ => "quotient")),
      ("type_hash",toJson (hash ci.type).toNat), ("body_hash", toJson ((ci.value? true).map fun e => (hash e).toNat)),
      ("deps",toJson (deps.map Name.toString)),("axiom",toJson isAx),
      ("has_body",toJson (ci.value? true).isSome),("unsafe",toJson ci.isUnsafe),
      ("partial",toJson ci.isPartial)])
  unless unsafeDecls.isEmpty do
    throwError "UNSAFE/PARTIAL {unsafeDecls} {partialDecls}"
  liftIO <| IO.FS.writeFile "/workspace/shared/distance-preserver-continuation/independent-audit-4c16b6a8-20261012/raw/body-closure.json" (Json.arr rows).compress
  liftIO <| IO.FS.writeFile "/workspace/shared/distance-preserver-continuation/independent-audit-4c16b6a8-20261012/raw/project-declarations.json" (toJson (project.map Name.toString)).compress
  logInfo m!"CHECKED_BODY_CLOSURE {rows.size}; axioms={axs.toArray}; unsafe={unsafeDecls}; partial={partialDecls}"

#check LinearDistancePreservers.theorem_one
#print axioms LinearDistancePreservers.theorem_one

#check LinearDistancePreservers.theorem_two
#print axioms LinearDistancePreservers.theorem_two

#check LinearDistancePreservers.matchingNumber_subquadratic
#print axioms LinearDistancePreservers.matchingNumber_subquadratic

#check LinearDistancePreservers.TheoremThree.bounded_range_lower_bound
#print axioms LinearDistancePreservers.TheoremThree.bounded_range_lower_bound

#check LinearDistancePreservers.TheoremThree.superquadratic_weighted_little_o
#print axioms LinearDistancePreservers.TheoremThree.superquadratic_weighted_little_o

#check LinearDistancePreservers.TheoremFourGeneral.uniform_dimension_lower_bound
#print axioms LinearDistancePreservers.TheoremFourGeneral.uniform_dimension_lower_bound

#check LinearDistancePreservers.TheoremFourGeneral.superquadratic_quarter_root
#print axioms LinearDistancePreservers.TheoremFourGeneral.superquadratic_quarter_root

#check LinearDistancePreservers.TheoremFourGeneral.superquadratic_quarter_root_eventual
#print axioms LinearDistancePreservers.TheoremFourGeneral.superquadratic_quarter_root_eventual

#check LinearDistancePreservers.ConsistentTiebreaking.optimal_subpaths_eq
#print axioms LinearDistancePreservers.ConsistentTiebreaking.optimal_subpaths_eq

#check LinearDistancePreservers.Routing.branch_vertex_unique
#print axioms LinearDistancePreservers.Routing.branch_vertex_unique

#check LinearDistancePreservers.Routing.edges_card_le
#print axioms LinearDistancePreservers.Routing.edges_card_le

#check LinearDistancePreservers.LazyTreeSelection.exists_lazy_tree
#print axioms LinearDistancePreservers.LazyTreeSelection.exists_lazy_tree

#check LinearDistancePreservers.LazyTreeSelection.branchEdges_le_two_demands
#print axioms LinearDistancePreservers.LazyTreeSelection.branchEdges_le_two_demands

#check LinearDistancePreservers.exists_favorable_cut
#print axioms LinearDistancePreservers.exists_favorable_cut

#check LinearDistancePreservers.ObstacleProduct.preserver_edge_count
#print axioms LinearDistancePreservers.ObstacleProduct.preserver_edge_count

#check LinearDistancePreservers.ObstacleProduct.exists_real_weighted_product
#print axioms LinearDistancePreservers.ObstacleProduct.exists_real_weighted_product

#check LinearDistancePreservers.ObstacleProduct.exists_real_weighted_forcing
#print axioms LinearDistancePreservers.ObstacleProduct.exists_real_weighted_forcing

#check LinearDistancePreservers.WeightedConstruction.designated_not_shortest
#print axioms LinearDistancePreservers.WeightedConstruction.designated_not_shortest

#check LinearDistancePreservers.ModularGraph.canonical_unique
#print axioms LinearDistancePreservers.ModularGraph.canonical_unique

#check LinearDistancePreservers.ModularGraph.canonical_incidence
#print axioms LinearDistancePreservers.ModularGraph.canonical_incidence

#check LinearDistancePreservers.DirectionEncoding.exact_arbitrary_layer_size
#print axioms LinearDistancePreservers.DirectionEncoding.exact_arbitrary_layer_size

#check LinearDistancePreservers.TheoremFourRateAudit.suppressed_expression_le
#print axioms LinearDistancePreservers.TheoremFourRateAudit.suppressed_expression_le

#check LinearDistancePreservers.SharedCopyLift.subset_lift
#print axioms LinearDistancePreservers.SharedCopyLift.subset_lift