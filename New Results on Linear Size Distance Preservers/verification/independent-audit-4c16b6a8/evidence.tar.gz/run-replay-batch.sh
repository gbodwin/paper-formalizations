#!/usr/bin/env bash
set -uo pipefail
O=/workspace/shared/distance-preserver-continuation/independent-audit-4c16b6a8-20261012
source "$O/env.sh"
exec 9>/workspace/shared/formalization-compiler.lock
flock -n 9 || exit 75
start=$SECONDS
echo "ACQUIRED $(date -u +%FT%TZ) $*"
for m in "$@"; do
  if (( SECONDS-start > 35 )); then echo BATCH_DEFERRED "$m"; break; fi
  echo "COMMAND leanchecker -j1 -DautoImplicit=false -v LinearDistancePreservers.$m"
  timeout "$((55-(SECONDS-start)))s" leanchecker -j1 -DautoImplicit=false -v "LinearDistancePreservers.$m" > "$O/raw/kernel-$m.log" 2>&1
  status=$?
  echo "RESULT $m $status $(date -u +%FT%TZ)"
  cat "$O/raw/kernel-$m.log"
  if (( status != 0 )); then break; fi
  if (( SECONDS-start > 50 )); then break; fi
done
echo "RELEASED $(date -u +%FT%TZ)"
exit "${status:-0}"
