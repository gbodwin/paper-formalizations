import LinearDistancePreservers.QuarterRootTheorem

/-- Independent audit check: the corrected quarter-root terminal cap is
nonempty for all sufficiently large natural graph sizes. -/
theorem audit_cap_ge_two (L : ℝ) (hL : (64 : ℝ)^4 ≤ L) :
    2 ≤ Real.exp ((2/3)*L-32*L^((3 : ℝ)/4)) := by
  let R := L^((4 : ℝ)⁻¹)
  have hL0 : 0 ≤ L := by linarith
  have hR0 : 0 ≤ R := Real.rpow_nonneg hL0 _
  have hR4 : R^4 = L := Real.rpow_inv_natCast_pow hL0 (by decide : (4 : ℕ) ≠ 0)
  have hR64 : 64 ≤ R := by
    apply (pow_le_pow_iff_left₀ (by norm_num) hR0 (by decide : (4 : ℕ) ≠ 0)).mp
    rwa [hR4]
  have hR3 : R^3 = L^((3 : ℝ)/4) := by
    dsimp [R]
    rw [← Real.rpow_mul_natCast hL0]
    norm_num
  have hprod := mul_le_mul_of_nonneg_right hR64 (pow_nonneg hR0 3)
  have hbudget : 32*L^((3 : ℝ)/4) ≤ L/2 := by
    rw [← hR3,← hR4]
    nlinarith only [hprod]
  have hone : 1 ≤ (2/3)*L-32*L^((3 : ℝ)/4) := by linarith
  have htwo : (2 : ℝ) ≤ Real.exp 1 := by
    have h := Real.add_one_le_exp (1 : ℝ)
    norm_num at h
    exact h
  exact htwo.trans (Real.exp_le_exp.mpr hone)

theorem audit_quarter_root_eventual_nonempty :
    ∃ N₀ : ℕ, ∀ N : ℕ, N₀ ≤ N → 2 ≤ N ∧
      (8 : ℝ)^4 ≤ Real.log N ∧
      (2 : ℝ) ≤ (N : ℝ)^((2 : ℝ)/3)*Real.exp (-32*(Real.log N)^((3 : ℝ)/4)) := by
  obtain ⟨N₀,hN₀⟩ := exists_nat_gt (Real.exp ((64 : ℝ)^4)+2)
  refine ⟨N₀,?_⟩
  intro N hN
  have hNN : (N₀ : ℝ) ≤ N := by exact_mod_cast hN
  have hN2 : (2 : ℝ) < N := by linarith [Real.exp_pos ((64 : ℝ)^4)]
  have hN0 : (0 : ℝ) < N := by linarith
  have hlog : (64 : ℝ)^4 ≤ Real.log N := by
    have h := Real.log_le_log (Real.exp_pos ((64 : ℝ)^4))
      (show Real.exp ((64 : ℝ)^4) ≤ (N : ℝ) by linarith)
    simpa only [Real.log_exp] using h
  refine ⟨by exact_mod_cast hN2.le,by linarith,?_⟩
  rw [Real.rpow_def_of_pos hN0,← Real.exp_add]
  convert audit_cap_ge_two (Real.log N) hlog using 1 <;> congr 1 <;> ring
