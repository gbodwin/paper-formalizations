from pathlib import Path
import json,hashlib,re,datetime,subprocess
b=Path('/workspace/shared/distance-preserver-continuation');o=b/'independent-audit-4c16b6a8-20261012';p=b/'audit-accepted-4c16b6a8';h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
ci=json.loads((o/'terminal-ci-receipt.json').read_text());assert ci['conclusion']=='success';source=json.loads((o/'source-verification.json').read_text());roots=json.loads((o/'root-body-closures.json').read_text());partial=json.loads((o/'generated-partial-inventory.json').read_text());assert not partial['theorems_affected']; assert all(not x['partial'] and not x['unsafe'] for x in roots)
manifest=json.loads((p/'manifest.json').read_text());bad=[f for f,s in manifest['file_sha256'].items() if h(p/f)!=s];assert not bad
fresh=[];replay=[]
for kind,arr in [('fresh',fresh),('kernel',replay)]:
 for f in sorted((o/'raw').glob(kind+'-batch-*.log')):
  for name,code,time in re.findall(r'^RESULT (\S+) (\d+) (\S+)',f.read_text(),re.M):arr.append({'module':'LinearDistancePreservers.'+name,'exit_code':int(code),'completed_at':time,'log':'raw/'+kind+'-'+name+'.log'})
assert len(fresh)==19 and all(x['exit_code']==0 for x in fresh);assert len(replay)>=10 and all(x['exit_code']==0 for x in replay)
assert 'STATEMENTS_EXIT=0' in (o/'raw/statements-retry.log').read_text();assert 'NONVACUITY_EXIT=0' in (o/'raw/supplementary-checks.log').read_text();assert 'BODY_AUDIT_EXIT=0' in (o/'raw/supplementary-checks.log').read_text();assert 'FRESH_REPLAY_PASS root=LinearDistancePreservers.TheoremFourGeneral.uniform_dimension_lower_bound constants=45841' in (o/'raw/fresh-closure-uniform.log').read_text()
for f in ['companion-markers.log','companion-dom.log']:
 assert 'PASS' in (o/'raw'/f).read_text()
assert '"passed": true' in (o/'raw/companion-diagrams.log').read_text()
body=json.loads((o/'raw/body-closure.json').read_text())
# Recheck reverse reachability on the final fresh body graph, not a prior receipt.
from collections import defaultdict
ix={x['name']:x for x in body}; rev=defaultdict(list)
for x in body:
 for dep in x['deps']:rev[dep].append(x['name'])
todo=[x['name'] for x in body if x['partial'] or x['unsafe']];hit=set()
while todo:
 n=todo.pop()
 if n in hit:continue
 hit.add(n);todo+=rev[n]
assert not [n for n in hit if ix[n]['kind']=='theorem']
partial['generated_partials']=[x for x in body if x['partial']];partial['transitive_dependents']=sorted(hit);partial['theorems_affected']=[]
project=[x for x in body if x['module'].startswith('LinearDistancePreservers.')];assert len(project)==2074
# Fresh graph may have been regenerated; bind partial reverse-dependency receipt to it.
partial['checked_body_graph_sha256']=h(o/'raw/body-closure.json');(o/'generated-partial-inventory.json').write_text(json.dumps(partial,indent=2))
arts=[]
for f in (o/'compiled/LinearDistancePreservers').glob('*.olean'):
 if not f.is_symlink():arts.append({'module':'LinearDistancePreservers.'+f.stem,'fresh_olean_sha256':h(f)})
(o/'fresh-artifact-hashes.json').write_text(json.dumps(arts,indent=2))
receipt={
 'schema_version':1,'audit_completed_at_utc':now,'verdict':'PASS','scope':'Accepted corrected mathematical results with documented helper replacements and finite-domain conventions',
 'exact_commit':ci['commit'],'exact_tree':ci['tree'],'frozen_manifest_sha256':h(p/'manifest.json'),'frozen_manifest_files':len(manifest['file_sha256']),'final_frozen_mismatches':bad,
 'original_literal_paper_certified':False,'accepted_main_results_complete':True,'mathematical_blockers':[],
 'nonblocking_findings':[{'id':'F1','severity':'documentation_underclaim','finding':'Old source headers still call now-discharged lattice/projection work unfinished.','locations':['LinearDistancePreservers/LatticeHull.lean:10-14','LinearDistancePreservers/HigherBehrend.lean:5-7','LinearDistancePreservers/HigherProduct.lean:5-8','LinearDistancePreservers/PathPerturbation.lean:4-8'],'remedy':'A later documentation-only cleanup should replace global unfinished-status phrases with downstream completion references. No proof repair is needed.'}],
 'scope_qualifications':['Theorem4 final consequence is the accepted 3/4-log-deficit replacement; the stronger original existential is neither proved nor refuted.','Lemma3 uses the sufficient ordered-triple p^3 bound; its literal binomial total count is not separately formalized.','Lemma5 uses nonroot-leaf inclusion and finite optimization; no executable O(n^2) modification-round/runtime result is certified.','Theorem5 uses k*x^2+1+a^2; the printed Euclidean construction is disproved, not validated.','The RS extremal implication is corrected. Weighted upper bound uses finite nonnegative weights; weighted forcing uses finite positive actual-edge weights and explicit symmetry.','Nonzero subset lower bounds require T>=2; distinct indexed auxiliary routes require positive depth.','Background cited estimates, open questions and signed/infinite-weight extensions are outside the claim.'],
 'ci':{k:v for k,v in ci.items() if k not in ['replay_names','all_steps']},
 'verification':{'paper_declarations':len(project),'paper_theorems':sum(x['kind']=='theorem' for x in project),'paper_modules':116,'checked_type_body_union_constants':len(body),'allowed_axioms':['propext','Classical.choice','Quot.sound'],'unsafe_union_constants':[],'generated_partial_helpers':[x['name'] for x in body if x['partial']],'all_project_theorems_free_of_partial_or_unsafe_dependencies':True,'inspected_root_closures':[{k:v for k,v in x.items() if k!='names'} for x in roots],'fresh_source_elaborations':fresh,'official_local_module_replays':replay,'empty_kernel_replay':{'root':'LinearDistancePreservers.TheoremFourGeneral.uniform_dimension_lower_bound','constants':45841,'passed':True,'log':'raw/fresh-closure-uniform.log'},'supplementary_nonvacuity_passed':True,'supplementary_definitions_printed':True,'dependency_modules_hashed':len(json.loads((o/'dependency-module-hashes.json').read_text())),'dependency_git_pins_verified':9,'local_module_indexes_reconciled':4},
 'companion':json.loads((o/'companion-verification.json').read_text()),
 'publication_conditions':['Refresh historical Site verification panel with this accepted corrected scope and exact CI/audit result.','Preserve original paper text, all12 marker controls and the corrected k*x^2 baseline.','Run final live access/audience, readback, fidelity, link and interaction checks; no fresh rendered pixel QA was performed in this audit.','Public links, deployment and audience changes are separate owner-authorized steps; none was performed here.'],
 'method_limits':['Risk-based manual source/proof-spine inspection plus exhaustive declaration/type/body closure checks; not a claim to have manually reread every imported proof line.','No full local rebuild of all116 paper modules or all mathlib; exact-commit full CI was independently verified, supplemented with19 fresh source elaborations.','Not every module was locally replayed; exact CI replayed all150 project modules including116 paper modules.','The standard Lean kernel and three listed foundational axioms remain trusted.','Reusable traversal/replay and nonvacuity harnesses were inspected and adapted from prior audit tooling; prior verdicts were not treated as proof authority.','Supplied original PDF/TeX bytes were manifest-verified and public v4 identity/text was separately checked; no second bytewise PDF download.','Other papers in the shared CI are outside this semantic audit.'],
 'evidence_files':{str(f.relative_to(o)):h(f) for f in [o/'semantic-findings.md',o/'source-verification.json',o/'candidate-delta-verification.json',o/'raw/body-closure.json',o/'declaration-inventory-by-module.json',o/'root-body-closures.json',o/'dependency-module-hashes.json',o/'dependency-pins.json',o/'raw/audit-checked-body-final.log',o/'raw/inspected-definitions.log',o/'terminal-ci-receipt.json',o/'raw/candidate-terminal-job.log',o/'original-source-receipt.json',o/'companion-verification.json']}
}
(o/'verdict.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
report=f'''# Independent audit: PASS for the accepted corrected mathematical results

Frozen commit: `{ci['commit']}`  
Exact tree: `{ci['tree']}`  
Audit completed: {now}

## Verdict

**PASS**, for the accepted corrected mathematical results with the documented helper replacements and finite-domain conventions. No additional missing main mathematical result, hidden axiom, admitted proof, circular main-theorem assumption, or unsafe proof dependency was found.

This is not certification of every literal original statement or proof method. A faithful public label is: **“Accepted corrected mathematical results verified in Lean, with documented helper replacements.”** The original stronger square-root-deficit consequence remains unresolved and is not refuted by the restricted obstruction results.

The proof package's mathematical/CI audit gate is complete. The local companion is **not yet a final deployment/completion page**: its historical status panel still needs the planned final refresh and live publication checks.

## What was verified

- All416 frozen manifest files, all284 exact Git-archive files, and the exact remote commit/tree binding. The13-file successor changes documentation/evidence, including a statement-printing-only Lean file; all116 production mathematical modules and CI/audit/replay code are unchanged from the mathematical parent. All112 prior-audit mathematical modules also remain unchanged.
- All four main results: actual directed and undirected upper-bound preservers; exact-size positive-weight lower bounds and little-o consequence; the common-coefficient uniform growing-dimension unweighted rate; and the accepted finite/eventual 3/4-log-deficit superquadratic consequence.
- Auxiliary Theorems5–6 and needed Lemmas1–7, including actual native distances, internally discharged path/geometry/scale inputs, edge ownership, arbitrary exact layer sizes, and a single positive perturbation scale preceding all endpoint pairs/competitors.
- All116 defining modules and2,074 paper declarations, including1,743 theorems. Checked type-and-body closure:49,287 constants, only `propext`, `Classical.choice`, `Quot.sound`; no unsafe constants. Three generated partial computational helpers are absent from every project theorem's proof closure, not merely the main roots.
- {len(fresh)} fresh selected source elaborations, {len(replay)} selected official local module replays,32 explicitly recorded theorem-root closures, and a complete45,841-constant replay of the uniform-dimension theorem into an empty kernel environment. All passed. Source/olean hashes cover1,748 dependency modules; all nine dependency Git pins match.
- A fresh supplementary proof check establishes eventual nonemptiness of the corrected terminal range; log N≥64⁴ suffices for T=2.

## Exact candidate CI

[Run38189023870]({ci['url']}) completed **SUCCESS** at {ci['completed_at']}, on the exact candidate SHA/tree above. All build, index, all-declaration axiom-audit and kernel-replay steps passed. The full raw job log independently matches all150 unique project replay names, including all116 distance-preserver modules, and records2,074 paper declarations.

Raw terminal log SHA-256: `{ci['raw_log_sha256']}`.  
Machine receipt: `terminal-ci-receipt.json`.

The mathematical parent's run38182298230 was also independently re-fetched and verified. Its supplied and freshly fetched logs differ only by one extra trailing newline in the supplied copy; no event differs.

## Material qualifications

1. Theorem4's accepted conclusion is T≤N^(2/3)exp(-32(log N)^(3/4)), with E≥T²exp(sqrt(log N)), and the correct finite/eventual order of quantifiers. The original stronger square-root-deficit existential is outside this accepted target.
2. Lemma3 uses E≤2n+p³ instead of a separately proved literal binomial(p,3) branching-triple total. It proves the same Theorem1 rate.
3. Lemma5 corrects leaf equality to nonroot-leaf inclusion. Finite minimization proves existence; executable rerouting rounds or running time are not certified.
4. Theorem5's repair is **k*x²+1+a²**, including the essential baseline. The Euclidean weighting has a verified counterexample.
5. The RS quantity uses the correct extremal direction. Nonzero subset lower bounds need at least two terminals; distinct indexed paths need positive depth. Finite nonnegative/positive weight domains remain explicit.
6. Cited background estimates, open questions, signed/infinite-weight extensions and arbitrary-graph impossibility claims are not included.

## Findings and companion gate

**F1, nonblocking documentation underclaim:** old module headers in LatticeHull, HigherBehrend, HigherProduct and PathPerturbation still call downstream work unfinished. Final exported statements and accepted-scope documentation are accurate. A later documentation-only cleanup should link the completing modules; no proof fix is needed.

The companion candidate preserves the old ten marker placements, all95 assets and the original article byte-for-byte outside markers. The three weight notes are corrected and two helper notes bring the total to12. Independently rerun DOM checks, all nine diagram checks and432 interaction groups at320/768/1440px passed. No fresh rendered pixel QA or live Site deployment was performed.

Before publication: refresh the historical status panel with this exact result; preserve all source content/markers; then verify the final live audience/access, readback, links, fidelity and interactions. Any public linking or audience change is a separate owner-controlled action.

## Detailed evidence and boundaries

- `semantic-findings.md`: statement-by-statement semantic analysis and source evidence
- `verdict.json`: exact-hash verdict, scope, checks, qualifications and exclusions
- `raw/audit-checked-body-final.log`, `raw/inspected-definitions.log`: elaborated root types, axioms and underlying definitions
- `declaration-inventory-by-module.json`, `raw/body-closure.json`, `root-body-closures.json`: exhaustive declaration and checked-body inventory
- `dependency-module-hashes.json`, `fresh-artifact-hashes.json`: source and compiled-artifact binding
- `COMMANDS.md`, checker sources and `raw/`: reproduction, commands, diagnostics and setup corrections

The original [arXiv v4 paper](https://arxiv.org/pdf/1605.01106v4) and supplied TeX were checked against the accepted contract. This was a skeptical semantic/proof-spine review plus exhaustive machine inspection, not a claim to manually reread every imported proof or rebuild all mathlib locally. The other papers sharing the CI run are outside this audit.
'''
# Normal spacing in reader-facing text, including counts and identifiers.
for a,z in [('All416','All 416'),('all284','all 284'),('The13','The 13'),('all116','all 116'),('All112','All 112'),('All116','All 116'),('and2,074','and 2,074'),('including1,743','including 1,743'),('closure:49,287','closure: 49,287'),('replays,32','replays, 32'),('complete45,841','complete 45,841'),('cover1,748','cover 1,748'),('Run38189023870','Run 38189023870'),('all150','all 150'),('records2,074','records 2,074'),('run38182298230','run 38182298230'),('Theorems5–6','Theorems 5–6'),('Lemmas1–7','Lemmas 1–7'),('Theorem4','Theorem 4'),('Theorem1','Theorem 1'),('Theorem5','Theorem 5'),('Lemma3','Lemma 3'),('Lemma5','Lemma 5'),('all95','all 95'),('to12','to 12'),('and432','and 432'),('at320','at 320')]:report=report.replace(a,z)
(o/'REPORT.md').write_text(report)
print(json.dumps({'verdict':'PASS','report':str(o/'REPORT.md'),'report_sha256':h(o/'REPORT.md'),'receipt':str(o/'verdict.json'),'receipt_sha256':h(o/'verdict.json'),'fresh_elaborations':len(fresh),'local_replays':len(replay),'terminal_ci':ci['run']},indent=2))
